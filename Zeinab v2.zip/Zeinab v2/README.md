# Fertility Diagnosis Prediction Web Application

## How to Run

1. **Install dependencies:**
   ```bash
   pip install flask pandas numpy scikit-learn joblib
   ```

2. **Start the server:**
   ```bash
   python app.py
   ```

3. **Open in browser:**
   Go to http://localhost:5000

## How to Upload Your Trained Model

### Option 1: Replace the Prediction Logic

1. **Train and save your model** from the Jupyter notebook:
   ```python
   # In your notebook, after training
   import joblib
   joblib.dump(model, 'fertility_model.pkl')
   joblib.dump(scaler, 'scaler.pkl')  # if you used scaling
   ```

2. **Modify app.py** to load your model:
   ```python
   # Replace the predict() function in app.py
   @app.route('/predict', methods=['POST'])
   def predict():
       try:
           # Load your trained model
           model = joblib.load('fertility_model.pkl')
           scaler = joblib.load('scaler.pkl')  # if needed
           
           # Get and preprocess data
           data = preprocess_data(form_data)
           
           # Make prediction
           prediction = model.predict(data)[0]
           probability = model.predict_proba(data)[0][1] * 100
           
           return jsonify({
               'prediction': 'Altered fertility' if prediction == 1 else 'Normal fertility',
               'probability': round(probability, 2)
           })
       except Exception as e:
           return jsonify({'error': str(e)}), 400
   ```

### Option 2: Quick Integration

1. **Save your model artifacts** in the project directory
2. **Update the preprocessing** in `preprocess_data()` function to match your notebook
3. **Replace the rule-based logic** with your actual model predictions

### Required Files

Place these files in the project root:
- `fertility_model.pkl` - Your trained model
- `scaler.pkl` - Your data scaler (if used)
- Update feature names in `preprocess_data()` to match your training data