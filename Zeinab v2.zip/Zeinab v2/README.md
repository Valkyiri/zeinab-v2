# Fertility Diagnosis App

## Quick Start
```bash
# Install dependencies
pip install streamlit pandas scikit-learn

# Run app
streamlit run streamlit_app.py
```

## Model Integration
Train your model in the notebook, then replace `make_prediction()` in `streamlit_app.py` with your model code.

App runs at: http://localhost:8501