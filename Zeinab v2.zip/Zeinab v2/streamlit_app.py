import streamlit as st
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
import joblib

# Page configuration
st.set_page_config(
    page_title="🧬 Fertility Diagnosis Prediction",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main {
        padding: 2rem;
    }
    .stButton>button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        padding: 0.75rem 2rem;
        font-size: 1.1rem;
        font-weight: 600;
        border-radius: 50px;
        width: 100%;
        margin-top: 2rem;
    }
    .stButton>button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
    }
    .result-box {
        padding: 2rem;
        border-radius: 15px;
        text-align: center;
        margin-top: 2rem;
    }
    .normal-result {
        background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
        color: #155724;
        border: 2px solid #c3e6cb;
    }
    .altered-result {
        background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
        color: #721c24;
        border: 2px solid #f5c6cb;
    }
    .stSlider {
        padding: 1rem 0;
    }
    h1 {
        color: #2c3e50;
        text-align: center;
        margin-bottom: 1rem;
    }
    h3 {
        color: #2c3e50;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
</style>
""", unsafe_allow_html=True)

def preprocess_data(data):
    """Preprocess the input data similar to the notebook"""
    df = pd.DataFrame([data])
    
    # Encode categorical variables
    le_season = LabelEncoder()
    le_childish = LabelEncoder()
    le_trauma = LabelEncoder()
    le_surgery = LabelEncoder()
    le_fevers = LabelEncoder()
    le_alcohol = LabelEncoder()
    le_smoking = LabelEncoder()
    
    # Fit encoders with possible values (based on the notebook)
    le_season.fit(['spring', 'summer', 'winter', 'autum'])
    le_childish.fit(['yes', 'no'])
    le_trauma.fit(['yes', 'no'])
    le_surgery.fit(['yes', 'no'])
    le_fevers.fit(['more than 3 months ago', 'less than 3 months', 'no'])
    le_alcohol.fit(['hardly ever or never', 'once a week', 'several times a week', 'several times a day'])
    le_smoking.fit(['never', 'occasional'])
    
    # Transform categorical variables
    df['Season'] = le_season.transform([df['Season'].iloc[0]])[0]
    df['Childish diseases'] = le_childish.transform([df['Childish diseases'].iloc[0]])[0]
    df['Accident or serious trauma'] = le_trauma.transform([df['Accident or serious trauma'].iloc[0]])[0]
    df['Surgical intervention'] = le_surgery.transform([df['Surgical intervention'].iloc[0]])[0]
    df['High fevers in the last year'] = le_fevers.transform([df['High fevers in the last year'].iloc[0]])[0]
    df['Frequency of alcohol consumption'] = le_alcohol.transform([df['Frequency of alcohol consumption'].iloc[0]])[0]
    df['Smoking habit'] = le_smoking.transform([df['Smoking habit'].iloc[0]])[0]
    
    return df

def make_prediction(data):
    """Make prediction using rule-based logic (replace with your model)"""
    # Simple rule-based prediction for demo
    risk_score = 0
    
    # Age factor
    if data['Age'] > 35:
        risk_score += 0.3
    
    # Hours sitting factor
    if data['Number of hours spent sitting per day'] > 8:
        risk_score += 0.2
    
    # Health factors
    if data['Childish diseases'] == 'yes':
        risk_score += 0.15
    if data['Accident or serious trauma'] == 'yes':
        risk_score += 0.15
    if data['Surgical intervention'] == 'yes':
        risk_score += 0.1
    if data['High fevers in the last year'] == 'less than 3 months':
        risk_score += 0.1
    
    # Lifestyle factors
    if data['Frequency of alcohol consumption'] == 'several times a day':
        risk_score += 0.1
    if data['Smoking habit'] == 'occasional':
        risk_score += 0.05
    
    # Make prediction based on risk score
    prediction = 1 if risk_score > 0.5 else 0
    probability = min(risk_score * 100, 95) if prediction == 1 else (1 - risk_score) * 100
    
    return {
        'prediction': 'Altered fertility' if prediction == 1 else 'Normal fertility',
        'probability': round(probability, 2),
        'risk_score': round(risk_score, 3)
    }

# Main app
def main():
    # Header
    st.title("🧬 Fertility Diagnosis Prediction App")
    st.write("Enter the details below to get a fertility diagnosis.")
    
    # Create two columns for better layout
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 Basic Information")
        age = st.slider("Age", 18, 50, 25)
        hours = st.slider("Number of hours spent sitting per day", 1, 16, 6)
        season = st.selectbox("Season", ["spring", "summer", "winter", "autum"])
        
        st.subheader("🏥 Medical History")
        childish = st.selectbox("Childish diseases", ["yes", "no"])
        trauma = st.selectbox("Accident or serious trauma", ["yes", "no"])
        surgery = st.selectbox("Surgical intervention", ["yes", "no"])
    
    with col2:
        st.subheader("🌡️ Recent Health")
        fevers = st.selectbox(
            "High fevers in last year",
            ["more than 3 months ago", "less than 3 months", "no"]
        )
        
        st.subheader("🍷 Lifestyle")
        alcohol = st.selectbox(
            "Frequency of alcohol consumption",
            ["hardly ever or never", "once a week", "several times a week", "several times a day"]
        )
        
        smoking = st.selectbox(
            "Smoking habit",
            ["never", "occasional"]
        )
    
    # Create data dictionary
    input_data = {
        "Age": age,
        "Number of hours spent sitting per day": hours,
        "Season": season,
        "Childish diseases": childish,
        "Accident or serious trauma": trauma,
        "Surgical intervention": surgery,
        "High fevers in the last year": fevers,
        "Frequency of alcohol consumption": alcohol,
        "Smoking habit": smoking
    }
    
    # Display entered data
    st.subheader("📋 Entered Data")
    df_display = pd.DataFrame([input_data])
    st.dataframe(df_display, use_container_width=True)
    
    # Prediction button
    if st.button("🔍 Predict Diagnosis"):
        with st.spinner("Analyzing your data..."):
            # Make prediction
            result = make_prediction(input_data)
            
            # Display results
            st.subheader("🔎 Prediction Result")
            
            if result['prediction'] == 'Altered fertility':
                st.error(f"🔴 Diagnosis: {result['prediction']}")
            else:
                st.success(f"🟢 Diagnosis: {result['prediction']}")
            
            st.info(f"Probability of altered fertility: {result['probability']}%")
            
            # Create result visualization
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Risk Score", f"{result['risk_score']}")
            with col2:
                st.metric("Confidence", f"{abs(50 - result['probability'])*2:.1f}%")
    
    # Footer
    st.divider()
    st.warning("⚠️ This is a demonstration tool. Consult with a healthcare professional for actual medical advice.")

if __name__ == "__main__":
    main()