from flask import Flask, request, jsonify, render_template
import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import StandardScaler, LabelEncoder
import os

app = Flask(__name__)

# Load the model (we'll create a simple model for demo)
# In a real scenario, you would load your trained model
model = None
scaler = StandardScaler()

# Feature columns based on the notebook
feature_columns = [
    'Age',
    'Number of hours spent sitting per day',
    'Season',
    'Childish diseases',
    'Accident or serious trauma',
    'Surgical intervention',
    'High fevers in the last year',
    'Frequency of alcohol consumption',
    'Smoking habit'
]

def preprocess_data(data):
    """Preprocess the input data similar to the notebook"""
    df = pd.DataFrame([data])
    
    # Encode categorical variables
    le_season = LabelEncoder()
    le_childish = LabelEncoder()
    le_trauma = LabelEncoder()
    le_surgery = LabelEncoder()
    le_fevers = LabelEncoder()
    le_alcohol = LabelEncoder()
    le_smoking = LabelEncoder()
    
    # Fit encoders with possible values (based on the notebook)
    le_season.fit(['spring', 'summer', 'winter', 'autum'])
    le_childish.fit(['yes', 'no'])
    le_trauma.fit(['yes', 'no'])
    le_surgery.fit(['yes', 'no'])
    le_fevers.fit(['more than 3 months ago', 'less than 3 months', 'no'])
    le_alcohol.fit(['hardly ever or never', 'once a week', 'several times a week', 'several times a day'])
    le_smoking.fit(['never', 'occasional'])
    
    # Transform categorical variables
    df['Season'] = le_season.transform([df['Season'].iloc[0]])[0]
    df['Childish diseases'] = le_childish.transform([df['Childish diseases'].iloc[0]])[0]
    df['Accident or serious trauma'] = le_trauma.transform([df['Accident or serious trauma'].iloc[0]])[0]
    df['Surgical intervention'] = le_surgery.transform([df['Surgical intervention'].iloc[0]])[0]
    df['High fevers in the last year'] = le_fevers.transform([df['High fevers in the last year'].iloc[0]])[0]
    df['Frequency of alcohol consumption'] = le_alcohol.transform([df['Frequency of alcohol consumption'].iloc[0]])[0]
    df['Smoking habit'] = le_smoking.transform([df['Smoking habit'].iloc[0]])[0]
    
    return df

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get data from the form
        data = {
            'Age': int(request.form['age']),
            'Number of hours spent sitting per day': int(request.form['hours']),
            'Season': request.form['season'],
            'Childish diseases': request.form['childish'],
            'Accident or serious trauma': request.form['trauma'],
            'Surgical intervention': request.form['surgery'],
            'High fevers in the last year': request.form['fevers'],
            'Frequency of alcohol consumption': request.form['alcohol'],
            'Smoking habit': request.form['smoking']
        }
        
        # Preprocess the data
        processed_data = preprocess_data(data)
        
        # For demo purposes, we'll create a simple prediction logic
        # In a real scenario, you would load your trained model here
        # This is a simplified version based on the patterns in the notebook
        
        # Simple rule-based prediction for demo
        risk_score = 0
        
        # Age factor
        if data['Age'] > 35:
            risk_score += 0.3
        
        # Hours sitting factor
        if data['Number of hours spent sitting per day'] > 8:
            risk_score += 0.2
        
        # Health factors
        if data['Childish diseases'] == 'yes':
            risk_score += 0.15
        if data['Accident or serious trauma'] == 'yes':
            risk_score += 0.15
        if data['Surgical intervention'] == 'yes':
            risk_score += 0.1
        if data['High fevers in the last year'] == 'less than 3 months':
            risk_score += 0.1
        
        # Lifestyle factors
        if data['Frequency of alcohol consumption'] == 'several times a day':
            risk_score += 0.1
        if data['Smoking habit'] == 'occasional':
            risk_score += 0.05
        
        # Make prediction based on risk score
        prediction = 1 if risk_score > 0.5 else 0
        probability = min(risk_score * 100, 95) if prediction == 1 else (1 - risk_score) * 100
        
        result = {
            'prediction': 'Altered fertility' if prediction == 1 else 'Normal fertility',
            'probability': round(probability, 2),
            'risk_score': round(risk_score, 3)
        }
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/health')
def health_check():
    return jsonify({'status': 'healthy'})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)