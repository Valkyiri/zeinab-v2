
const form = document.getElementById('predictionForm');
const resultContainer = document.getElementById('result');
const loadingDiv = document.getElementById('loading');
const predictionText = document.getElementById('predictionText');
const probabilityText = document.getElementById('probabilityText');
const riskScoreText = document.getElementById('riskScoreText');


const ageSlider = document.getElementById('age');
const ageValue = document.getElementById('ageValue');
const hoursSlider = document.getElementById('hours');
const hoursValue = document.getElementById('hoursValue');


ageSlider.addEventListener('input', function() {
    ageValue.textContent = this.value;
});

hoursSlider.addEventListener('input', function() {
    hoursValue.textContent = this.value;
});


form.addEventListener('submit', async function(e) {
    e.preventDefault();
    

    resultContainer.style.display = 'none';
    loadingDiv.style.display = 'block';
    

    const formData = new FormData(form);
    
    try {
        // Send POST request to Flask backend
        const response = await fetch('/predict', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const result = await response.json();
        
 
        loadingDiv.style.display = 'none';
        resultContainer.style.display = 'block';
        
    
        displayResults(result);
        
    } catch (error) {
       
        loadingDiv.style.display = 'none';
        resultContainer.style.display = 'block';
        
        
        displayError(error.message);
    }
});

function displayResults(result) {
   
    predictionText.className = 'prediction-text';
    
    
    if (result.prediction === 'Normal fertility') {
        predictionText.textContent = '🟢 Normal Fertility';
        predictionText.classList.add('normal');
    } else {
        predictionText.textContent = '🔴 Altered Fertility';
        predictionText.classList.add('altered');
    }
    
  
    probabilityText.textContent = `Probability of altered fertility: ${result.probability}%`;
    
   
    riskScoreText.textContent = `Risk Score: ${result.risk_score}`;
    
  
    const resultCard = document.querySelector('.result-card');
    resultCard.style.animation = 'none';
    resultCard.offsetHeight; // Trigger reflow
    resultCard.style.animation = 'fadeInUp 0.5s ease-out';
}

function displayError(message) {
    predictionText.textContent = '❌ Error';
    predictionText.className = 'prediction-text altered';
    probabilityText.textContent = 'Unable to process your request';
    riskScoreText.textContent = `Error: ${message}`;
}


function scrollToResults() {
    setTimeout(() => {
        resultContainer.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'nearest' 
        });
    }, 100);
}


const originalSubmitHandler = form.addEventListener('submit', async function(e) {
    e.preventDefault();
    
  
    resultContainer.style.display = 'none';
    loadingDiv.style.display = 'block';
    

    const formData = new FormData(form);
    
    try {
       
        const response = await fetch('/predict', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const result = await response.json();
        
    
        loadingDiv.style.display = 'none';
        resultContainer.style.display = 'block';
        
     
        displayResults(result);
        
     
        scrollToResults();
        
    } catch (error) {
    
        loadingDiv.style.display = 'none';
        resultContainer.style.display = 'block';
        
    
        displayError(error.message);
        

        scrollToResults();
    }
});


function validateForm() {
    const age = parseInt(ageSlider.value);
    const hours = parseInt(hoursSlider.value);
    
    if (age < 18 || age > 50) {
        alert('Age must be between 18 and 50');
        return false;
    }
    
    if (hours < 1 || hours > 16) {
        alert('Hours spent sitting must be between 1 and 16');
        return false;
    }
    
    return true;
}


form.addEventListener('submit', function(e) {
    if (!validateForm()) {
        e.preventDefault();
        return;
    }
});


document.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && e.target.tagName !== 'BUTTON') {
        const formElements = Array.from(form.elements);
        const currentIndex = formElements.indexOf(e.target);
        
        if (currentIndex < formElements.length - 1) {
            e.preventDefault();
            formElements[currentIndex + 1].focus();
        }
    }
});


const formInputs = form.querySelectorAll('input, select');
formInputs.forEach(input => {
    input.addEventListener('focus', function() {
        this.parentElement.style.transform = 'scale(1.02)';
        this.parentElement.style.transition = 'transform 0.2s ease';
    });
    
    input.addEventListener('blur', function() {
        this.parentElement.style.transform = 'scale(1)';
    });
});


document.addEventListener('DOMContentLoaded', function() {
 
    ageValue.textContent = ageSlider.value;
    hoursValue.textContent = hoursSlider.value;
    

    const submitBtn = document.querySelector('.submit-btn');
    setInterval(() => {
        submitBtn.style.boxShadow = '0 6px 25px rgba(102, 126, 234, 0.5)';
        setTimeout(() => {
            submitBtn.style.boxShadow = '0 4px 15px rgba(102, 126, 234, 0.3)';
        }, 1000);
    }, 3000);
});