#!/usr/bin/env python3
"""
Minimal setup script for Fertility Diagnosis Prediction App
Run this script to install dependencies and start the Streamlit app
"""

import subprocess
import sys
import os

def install_dependencies():
    """Install required packages"""
    print("Installing dependencies...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Dependencies installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing dependencies: {e}")
        return False

def run_streamlit():
    """Run the Streamlit app"""
    print("Starting Streamlit app...")
    try:
        subprocess.run([sys.executable, "-m", "streamlit", "run", "streamlit_app.py"])
    except KeyboardInterrupt:
        print("\n👋 App stopped by user")
    except Exception as e:
        print(f"❌ Error running Streamlit: {e}")

def main():
    """Main setup function"""
    print("🧬 Fertility Diagnosis Prediction App Setup")
    print("=" * 50)
    
    # Check if requirements.txt exists
    if not os.path.exists("requirements.txt"):
        print("❌ requirements.txt not found!")
        return
    
    # Install dependencies
    if install_dependencies():
        print("\n🚀 Starting the app...")
        run_streamlit()
    else:
        print("\n❌ Setup failed. Please install dependencies manually.")
        print("Run: pip install streamlit pandas scikit-learn")

if __name__ == "__main__":
    main()